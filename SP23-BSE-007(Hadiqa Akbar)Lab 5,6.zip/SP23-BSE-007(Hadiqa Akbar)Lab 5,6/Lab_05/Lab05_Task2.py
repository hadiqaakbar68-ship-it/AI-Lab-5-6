# Lab05_Task2_8_Puzzle_GBFS.py

import heapq

import math

from collections import deque

def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)

GOAL = (1, 2, 3, 4, 5, 6, 7, 8, 0)

def misplaced(state):
    return sum(1 for i, t in enumerate(state) if t != 0 and t != GOAL[i])

def neighbours(state):
    blank = state.index(0)
    r, c = divmod(blank, 3)
    result = []
    for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        nr, nc = r + dr, c + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            lst = list(state)
            j = nr * 3 + nc
            lst[blank], lst[j] = lst[j], lst[blank]
            result.append(tuple(lst))
    return result

def show_state(state):
    for i in range(0, 9, 3):
        print("   " + " ".join(str(t) if t else "_" for t in state[i:i + 3]))

def build_path(parent, state):
    path = []
    while state is not None:
        path.append(state)
        state = parent[state]
    return path[::-1]

def puzzle_gbfs(start):
    counter = 0
    heap = [(misplaced(start), counter, start)]
    parent = {start: None}
    closed = set()
    while heap:
        _, _, cur = heapq.heappop(heap)
        if cur in closed:
            continue
        closed.add(cur)
        if cur == GOAL:
            return build_path(parent, cur), len(closed)
        for nb in neighbours(cur):
            if nb not in parent:
                parent[nb] = cur
                counter += 1
                heapq.heappush(heap, (misplaced(nb), counter, nb))
    return None, len(closed)

def print_solution(path):
    for step, st in enumerate(path):
        print(f"Step {step}  (h = {misplaced(st)})")
        show_state(st)
    print("Total steps in solution:", len(path) - 1)

def lab5_task2():
    banner("LAB 5 - Task 2: 8-puzzle using GBFS")
    start = (1, 2, 3, 4, 0, 6, 7, 5, 8)
    path, explored = puzzle_gbfs(start)
    print_solution(path)
    print("States explored:", explored)

if __name__ == "__main__":
    lab5_task2()
