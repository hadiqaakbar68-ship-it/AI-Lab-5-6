# Lab05_Activity2_Changed_Heuristic.py

import math

from collections import deque

def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)

LAB5_GRAPH = {
    'A': ['B', 'C'], 'B': ['D', 'E'], 'C': ['F'],
    'D': ['G'], 'E': ['G'], 'F': ['G'], 'G': [],
}

HEURISTIC_2 = {'A': 7, 'B': 2, 'C': 5, 'D': 1, 'E': 3, 'F': 2, 'G': 0}

def greedy_best_first(graph, h, start, goal):
    frontier = [start]
    visited = set()
    order = []
    while frontier:
        current = min(frontier, key=lambda n: h[n])
        frontier.remove(current)
        order.append(current)
        print(current)
        if current == goal:
            print("Goal found!")
            return order
        visited.add(current)
        for nb in graph[current]:
            if nb not in visited and nb not in frontier:
                frontier.append(nb)
    return None

def lab5_activity2():
    banner("LAB 5 - Activity 2: GBFS with changed heuristic")
    order = greedy_best_first(LAB5_GRAPH, HEURISTIC_2, 'A', 'G')
    print("Nodes explored (new heuristic):", " -> ".join(order))
    print("Nodes explored (old heuristic): A -> C -> F -> G")
    print("Discussion: graph same hai, sirf h(n) badla, is liye search ka "
          "raasta badal gaya (A-C-F-G se A-B-D-G). Matlab informed search "
          "ka behaviour heuristic par depend karta hai.")

if __name__ == "__main__":
    lab5_activity2()
