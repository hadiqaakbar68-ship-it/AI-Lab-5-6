# Lab05_Task1_Manhattan_Distance.py
import heapq

import math

from collections import deque

def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)

def manhattan_distance(current, goal):
    return abs(current[0] - goal[0]) + abs(current[1] - goal[1])

def lab5_task1():
    banner("LAB 5 - Task 1: Manhattan distance heuristic")
    goal = (4, 4)
    positions = [(0, 0), (1, 2), (2, 3), (3, 4), (4, 4)]
    for p in positions:
        print(f"h{p} = |{goal[0]}-{p[0]}| + |{goal[1]}-{p[1]}| = "
              f"{manhattan_distance(p, goal)}")

if __name__ == "__main__":
    lab5_task1()
