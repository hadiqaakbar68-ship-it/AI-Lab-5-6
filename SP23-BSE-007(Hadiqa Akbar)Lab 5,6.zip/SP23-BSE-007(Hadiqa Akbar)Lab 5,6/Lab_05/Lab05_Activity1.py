# Lab05_Activity1_GBFS.py


import heapq

import math

from collections import deque

def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)

LAB5_GRAPH = {
    'A': ['B', 'C'], 'B': ['D', 'E'], 'C': ['F'],
    'D': ['G'], 'E': ['G'], 'F': ['G'], 'G': [],
}

HEURISTIC_1 = {'A': 7, 'B': 5, 'C': 3, 'D': 4, 'E': 2, 'F': 1, 'G': 0}

def greedy_best_first(graph, h, start, goal):
    frontier = [start]
    visited = set()
    order = []
    while frontier:
        current = min(frontier, key=lambda n: h[n])
        frontier.remove(current)
        order.append(current)
        print(current)
        if current == goal:
            print("Goal found!")
            return order
        visited.add(current)
        for nb in graph[current]:
            if nb not in visited and nb not in frontier:
                frontier.append(nb)
    return None

def lab5_activity1():
    banner("LAB 5 - Activity 1: GBFS with the given heuristic")
    order = greedy_best_first(LAB5_GRAPH, HEURISTIC_1, 'A', 'G')
    print("Nodes explored:", " -> ".join(order))

if __name__ == "__main__":
    lab5_activity1()
