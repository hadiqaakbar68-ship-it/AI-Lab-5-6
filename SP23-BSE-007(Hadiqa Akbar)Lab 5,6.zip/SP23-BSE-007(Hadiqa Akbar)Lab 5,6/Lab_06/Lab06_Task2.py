# Lab06_Task2_8_Puzzle_A_Star.py
import heapq

import math

from collections import deque

def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)

GOAL = (1, 2, 3, 4, 5, 6, 7, 8, 0)

def misplaced(state):
    return sum(1 for i, t in enumerate(state) if t != 0 and t != GOAL[i])

def neighbours(state):
    blank = state.index(0)
    r, c = divmod(blank, 3)
    result = []
    for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        nr, nc = r + dr, c + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            lst = list(state)
            j = nr * 3 + nc
            lst[blank], lst[j] = lst[j], lst[blank]
            result.append(tuple(lst))
    return result

def is_solvable(state):
    tiles = [t for t in state if t != 0]
    inversions = sum(1 for i in range(len(tiles))
                     for j in range(i + 1, len(tiles)) if tiles[i] > tiles[j])
    return inversions % 2 == 0

def show_state(state):
    for i in range(0, 9, 3):
        print("   " + " ".join(str(t) if t else "_" for t in state[i:i + 3]))

def build_path(parent, state):
    path = []
    while state is not None:
        path.append(state)
        state = parent[state]
    return path[::-1]

def puzzle_astar(start):
    counter = 0
    heap = [(misplaced(start), 0, counter, start)]
    g_cost = {start: 0}
    parent = {start: None}
    closed = set()
    while heap:
        f, g, _, cur = heapq.heappop(heap)
        if cur in closed:
            continue
        closed.add(cur)
        if cur == GOAL:
            return build_path(parent, cur), g, len(closed)
        for nb in neighbours(cur):
            ng = g + 1                       # every tile move costs 1
            if nb not in g_cost or ng < g_cost[nb]:
                g_cost[nb] = ng
                parent[nb] = cur
                counter += 1
                heapq.heappush(heap, (ng + misplaced(nb), ng, counter, nb))
    return None, None, len(closed)

def lab6_task2():
    banner("LAB 6 - Task 2: 8-puzzle using A*")
    for start in [(1, 2, 3, 4, 0, 6, 7, 5, 8), (8, 1, 3, 4, 0, 2, 7, 6, 5)]:
        if not is_solvable(start):
            print("Not solvable:", start)
            continue
        path, cost, explored = puzzle_astar(start)
        for i, st in enumerate(path):
            g = i
            h = misplaced(st)
            print(f"Step {i}: g = {g}, h = {h}, f = {g + h}")
            show_state(st)
        print("Total cost:", cost, "| states explored:", explored, "\n")

if __name__ == "__main__":
    lab6_task2()
