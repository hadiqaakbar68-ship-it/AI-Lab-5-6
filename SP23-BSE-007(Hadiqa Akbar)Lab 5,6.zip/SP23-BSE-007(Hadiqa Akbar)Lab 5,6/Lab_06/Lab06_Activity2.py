# Lab06_Activity2_Maze_A_Star.py
import heapq

import math

from collections import deque

def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)

def manhattan_distance(current, goal):
    return abs(current[0] - goal[0]) + abs(current[1] - goal[1])

MAZE_NODES = {
    'A': (0, 0), 'B': (2, 0), 'C': (3, 0), 'D': (4, 0), 'E': (5, 0),
    'F': (0, 1), 'G': (2, 1), 'H': (0, 2), 'I': (1, 2), 'J': (2, 2),
    'K': (4, 2), 'L': (5, 2), 'M': (0, 3), 'N': (1, 3), 'O': (3, 3),
    'P': (4, 3), 'Q': (5, 3), 'R': (0, 4), 'S': (1, 4), 'T': (2, 4),
    'U': (3, 4), 'V': (5, 4), 'W': (2, 5), 'X': (4, 5), 'Y': (5, 5),
}

def maze_graph():
    """Neighbours are generated automatically from the coordinates."""
    by_pos = {pos: name for name, pos in MAZE_NODES.items()}
    g = {}
    for name, (x, y) in MAZE_NODES.items():
        g[name] = [by_pos[p] for p in ((x, y + 1), (x, y - 1), (x - 1, y), (x + 1, y))
                   if p in by_pos]
    return g

def lab6_activity2():
    banner("LAB 6 - Activity 2: Maze path planning (A*)")
    graph = maze_graph()
    goal = 'Y'
    h = lambda n: manhattan_distance(MAZE_NODES[n], MAZE_NODES[goal])

    heap = [(h('A'), 'A')]
    g_cost = {'A': 0}
    parent = {'A': None}
    closed = set()
    while heap:
        f, cur = heapq.heappop(heap)
        if cur in closed:
            continue
        print(f"Node: {cur} g = {g_cost[cur]} h = {h(cur)} f = {f}")
        if cur == goal:
            break
        closed.add(cur)
        for nb in graph[cur]:
            ng = g_cost[cur] + 1
            if nb not in g_cost or ng < g_cost[nb]:
                g_cost[nb] = ng
                parent[nb] = cur
                heapq.heappush(heap, (ng + h(nb), nb))
    path = []
    n = goal
    while n is not None:
        path.append(n)
        n = parent[n]
    path.reverse()
    print("\nFinal Path:", path)
    print("Total Path Cost:", len(path) - 1)

if __name__ == "__main__":
    lab6_activity2()
