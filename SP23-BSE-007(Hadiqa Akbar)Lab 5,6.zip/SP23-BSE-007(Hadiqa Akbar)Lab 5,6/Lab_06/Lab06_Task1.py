# Lab06_Task1_Romania_Map_A_Star_UCS_BFS.py
import heapq

import math

from collections import deque

def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)

ROMANIA = {
    'Arad': {'Zerind': 75, 'Sibiu': 140, 'Timisoara': 118},
    'Zerind': {'Arad': 75, 'Oradea': 71},
    'Oradea': {'Zerind': 71, 'Sibiu': 151},
    'Sibiu': {'Arad': 140, 'Oradea': 151, 'Fagaras': 99, 'Rimnicu Vilcea': 80},
    'Timisoara': {'Arad': 118, 'Lugoj': 111},
    'Lugoj': {'Timisoara': 111, 'Mehadia': 70},
    'Mehadia': {'Lugoj': 70, 'Dobreta': 75},
    'Dobreta': {'Mehadia': 75, 'Craiova': 120},
    'Craiova': {'Dobreta': 120, 'Rimnicu Vilcea': 146, 'Pitesti': 138},
    'Rimnicu Vilcea': {'Sibiu': 80, 'Craiova': 146, 'Pitesti': 97},
    'Fagaras': {'Sibiu': 99, 'Bucharest': 211},
    'Pitesti': {'Rimnicu Vilcea': 97, 'Craiova': 138, 'Bucharest': 101},
    'Bucharest': {'Fagaras': 211, 'Pitesti': 1001, 'Urziceni': 85, 'Giurgiu': 90},
    'Giurgiu': {'Bucharest': 90},
    'Urziceni': {'Bucharest': 85, 'Hirsova': 98, 'Vaslui': 142},
    'Hirsova': {'Urziceni': 98, 'Eforie': 86},
    'Eforie': {'Hirsova': 86},
    'Vaslui': {'Urziceni': 142, 'Iasi': 92},
    'Iasi': {'Vaslui': 92, 'Neamt': 87},
    'Neamt': {'Iasi': 87},
}

SLD = {
    'Arad': 366, 'Bucharest': 0, 'Craiova': 160, 'Dobreta': 242, 'Eforie': 161,
    'Fagaras': 176, 'Giurgiu': 77, 'Hirsova': 151, 'Iasi': 226, 'Lugoj': 244,
    'Mehadia': 241, 'Neamt': 234, 'Oradea': 380, 'Pitesti': 100,
    'Rimnicu Vilcea': 193, 'Sibiu': 253, 'Timisoara': 329, 'Urziceni': 80,
    'Vaslui': 199, 'Zerind': 374,
}

def best_first_cost(graph, start, goal, h):
    """A* when h = SLD, Uniform Cost Search when h = 0. Returns path, cost, expanded."""
    heap = [(h(start), 0, start)]
    best_g = {start: 0}
    parent = {start: None}
    closed = set()
    expanded = []
    while heap:
        f, g, cur = heapq.heappop(heap)
        if cur in closed:
            continue
        closed.add(cur)
        expanded.append(cur)
        if cur == goal:
            path = []
            while cur:
                path.append(cur)
                cur = parent[cur]
            return path[::-1], g, expanded
        for nb, w in graph[cur].items():
            ng = g + w
            if nb not in best_g or ng < best_g[nb]:
                best_g[nb] = ng
                parent[nb] = cur
                heapq.heappush(heap, (ng + h(nb), ng, nb))
    return None, None, expanded

def bfs(graph, start, goal):
    queue = deque([start])
    parent = {start: None}
    expanded = []
    while queue:
        cur = queue.popleft()
        expanded.append(cur)
        if cur == goal:
            path = []
            while cur:
                path.append(cur)
                cur = parent[cur]
            return path[::-1], expanded
        for nb in graph[cur]:
            if nb not in parent:
                parent[nb] = cur
                queue.append(nb)
    return None, expanded

def road_cost(path):
    return sum(ROMANIA[a][b] for a, b in zip(path, path[1:]))

def lab6_task1():
    banner("LAB 6 - Task 1: A* on Arad -> Bucharest + comparison")
    p, c, ex = best_first_cost(ROMANIA, 'Arad', 'Bucharest', lambda n: SLD[n])
    print("A*  path :", " -> ".join(p))
    print("A*  cost :", c, "km | nodes expanded:", len(ex))
    print("A*  order:", ex)

    p2, c2, ex2 = best_first_cost(ROMANIA, 'Arad', 'Bucharest', lambda n: 0)
    print("\nUCS path :", " -> ".join(p2))
    print("UCS cost :", c2, "km | nodes expanded:", len(ex2))

    p3, ex3 = bfs(ROMANIA, 'Arad', 'Bucharest')
    print("\nBFS path :", " -> ".join(p3))
    print("BFS cost :", road_cost(p3), "km | nodes expanded:", len(ex3))

    print("\nImprovements noticed:")
    print(f"1) A* ne sirf {len(ex)} nodes expand kiye, UCS ne {len(ex2)} aur "
          f"BFS ne {len(ex3)}.")
    print(f"2) A* ne optimal path ({c} km) mila, jabke BFS ne kam hops wala "
          f"lekin mehnga path ({road_cost(p3)} km) diya.")
    print("3) Heuristic (straight-line distance) search ko Bucharest ki taraf "
          "guide karti hai, is liye ghair zaroori shehron ki taraf nahi jata.")

if __name__ == "__main__":
    lab6_task1()
