# Lab06_Activity1_Heuristics.py


import heapq

import math

from collections import deque

def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)

def manhattan_distance(current, goal):
    return abs(current[0] - goal[0]) + abs(current[1] - goal[1])

def diagonal_distance(current, goal):
    return max(abs(current[0] - goal[0]), abs(current[1] - goal[1]))

def euclidean_distance(current, goal):
    return math.sqrt((goal[0] - current[0]) ** 2 + (goal[1] - current[1]) ** 2)

def lab6_activity1():
    banner("LAB 6 - Activity 1: Heuristic functions")
    cur, goal = (1, 1), (4, 8)
    print("Manhattan :", manhattan_distance(cur, goal))
    print("Diagonal  :", diagonal_distance(cur, goal))
    print("Euclidean :", euclidean_distance(cur, goal))

if __name__ == "__main__":
    lab6_activity1()
