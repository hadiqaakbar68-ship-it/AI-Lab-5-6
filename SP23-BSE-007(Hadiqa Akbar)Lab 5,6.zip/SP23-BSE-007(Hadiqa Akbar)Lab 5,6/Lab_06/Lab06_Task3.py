# Lab06_Task3_Robot_Maze_A_Star.py

import heapq

import math

from collections import deque

def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)

def manhattan_distance(current, goal):
    return abs(current[0] - goal[0]) + abs(current[1] - goal[1])

MAZE = [
    "S...#.....",
    "..#...##..",
    "...#..##.#",
    ".#..#...##",
    ".##.......",
    ".#..###.##",
    "#..###....",
    ".###......",
    "#.###...#G",
]

DIRS = [(-1, 0), (0, 1), (1, 0), (0, -1)]

DIR_NAMES = ["North", "East", "South", "West"]

def find_cell(ch):
    for r, row in enumerate(MAZE):
        if ch in row:
            return (r, row.index(ch))

def maze_free(r, c):
    return 0 <= r < len(MAZE) and 0 <= c < len(MAZE[0]) and MAZE[r][c] != '#'

def lab6_task3():
    banner("LAB 6 - Task 3: Robot maze using A*")
    start, goal = find_cell('S'), find_cell('G')
    h = lambda pos: manhattan_distance(pos, goal)
    # state = (row, col, facing). Turn = cost 1, moving k cells forward = cost k
    s0 = (start[0], start[1], 1)                       # robot starts facing East
    heap = [(h(start), 0, 0, s0)]
    g_cost = {s0: 0}
    parent = {s0: (None, "start")}
    closed = set()
    tie = 0
    final = None
    while heap:
        f, g, _, st = heapq.heappop(heap)
        if st in closed:
            continue
        closed.add(st)
        r, c, d = st
        if (r, c) == goal:
            final = st
            break
        moves = [((r, c, (d + 1) % 4), 1, "turn right"),
                 ((r, c, (d - 1) % 4), 1, "turn left")]
        k = 1
        while maze_free(r + DIRS[d][0] * k, c + DIRS[d][1] * k):
            nr, nc = r + DIRS[d][0] * k, c + DIRS[d][1] * k
            moves.append(((nr, nc, d), k, f"move {DIR_NAMES[d]} {k}"))
            k += 1
        for ns, cost, label in moves:
            ng = g + cost
            if ns not in g_cost or ng < g_cost[ns]:
                g_cost[ns] = ng
                parent[ns] = (st, label)
                tie += 1
                heapq.heappush(heap, (ng + h(ns[:2]), ng, tie, ns))
    if final is None:
        print("No path found.")
        return
    steps = []
    st = final
    while st is not None:
        prev, label = parent[st]
        steps.append((st, label))
        st = prev
    steps.reverse()
    print("Actions taken:")
    for st, label in steps[1:]:
        print(f"  {label:<15} -> now at ({st[0]}, {st[1]}) facing {DIR_NAMES[st[2]]}")
    coords = [steps[0][0][:2]]
    for st, _ in steps[1:]:
        if st[:2] != coords[-1]:
            coords.append(st[:2])
    print("\nPath (row, col):", coords)
    print("Total cost:", g_cost[final])

if __name__ == "__main__":
    lab6_task3()
